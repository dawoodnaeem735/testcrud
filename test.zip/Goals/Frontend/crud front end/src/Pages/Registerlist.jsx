import React from 'react'

const Registerlist = () => {
  return (
  


    <>
    
    
    <br />
    <br />

<div className="container">

    <center><h1>REGISTER LIST FORM</h1></center>
    
    <table class="table">
  <thead>
    <tr>
      <th scope="col">ID</th>
      <th scope="col">Username</th>
      <th scope="col">User Email</th>
      <th scope="col">User password</th>
      <th scope="col">Delete</th>
      <th scope="col">Update</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>Talha</td>
      <td>Talha@gmail.com</td>
      <td>Talha</td>
      <td>
  <button class="btn btn-danger">Delete</button>
</td>
<td>
<button class="btn btn-primary ms-2" >Update</button>
</td>

    </tr>
    
   
  </tbody>
</table>


</div>

    </>



  )
}

export default Registerlist