
const express = require("express");

const app = express();

require("dotenv").config();

//View ejs

app.set("view engine","ejs");

//Code with Json langugae

app.use(express.json());

//App use Form Api data pass

app.use(express.urlencoded({extended:true}));

//connectionDB

const {DBconnection} = require("./Config/Db");

//model

const {Users} = require("./Model/users");

//Import Controllers

const {UserRegisterpage,UserRegistercreate,deleteRole,update} = require("./Controllers/UserController");

//App route GET & POST

app.route("/Register").get(UserRegisterpage).post(UserRegistercreate);

app.route("/Register/:UserName").delete(deleteRole).put(update)



app.listen(process.env.PORT, function() {
    console.log(`Server is running on PORT ${process.env.PORT}`);
    DBconnection();
});

